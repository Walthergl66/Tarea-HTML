const express = require('express');
const fs = require('fs');

const app = express();
app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

// Ruta para obtener artículos
app.get('/get-articles', (req, res) => {
    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);
        const pendingArticles = articles.filter(article => article.status === 'pendiente');
        res.json(pendingArticles);
    });
});

// Ruta para aprobar un artículo
app.post('/approve-article/:id', (req, res) => {
    const articleId = req.params.id;

    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);
        const article = articles.find(a => a.id === parseInt(articleId));

        if (!article) {
            return res.status(404).json({ success: false, message: 'Artículo no encontrado' });
        }

        article.status = 'aprobado';

        fs.writeFile('articles.json', JSON.stringify(articles, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error al guardar el artículo' });
            }
            res.json({ success: true });
        });
    });
});

// Ruta para rechazar un artículo
app.post('/reject-article/:id', (req, res) => {
    const articleId = req.params.id;

    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);
        const article = articles.find(a => a.id === parseInt(articleId));

        if (!article) {
            return res.status(404).json({ success: false, message: 'Artículo no encontrado' });
        }

        article.status = 'rechazado';

        fs.writeFile('articles.json', JSON.stringify(articles, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error al guardar el artículo' });
            }
            res.json({ success: true });
        });
    });
});

app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
